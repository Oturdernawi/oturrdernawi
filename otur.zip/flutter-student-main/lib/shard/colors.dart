import 'package:flutter/material.dart';

 const binpink = Color.fromARGB(255, 241, 39, 100);
 const btngreen = Color.fromARGB(255, 73, 179, 105);
 const appbarGreen = Color.fromARGB(255, 76, 141, 95);