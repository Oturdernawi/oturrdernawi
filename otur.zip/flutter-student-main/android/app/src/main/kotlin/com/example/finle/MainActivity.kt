package com.example.finle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
